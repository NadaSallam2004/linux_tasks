# Assignment 1 – Arithmetic Operations

سكريبت Bash بياخد رقمين صحيحين من المستخدم ويطبع عليهم خمس عمليات حسابية: الجمع، الطرح، الضرب، القسمة، وباقي القسمة (Modulus).

---

## المطلوب (من التاسك)

> Ask the user for two integers, and display:
> - Sum
> - Difference
> - Multiplication
> - Division
> - Modulus

مثال متوقع:
```
Enter first number: 20
Enter second number: 5

Sum = 25
Difference = 15
Multiplication = 100
Division = 4
Modulus = 0
```

---

## الملف: `arithmetic.sh`

السكريبت بيتعمل بالخطوات دي:

```bash
cd ~
nano arithmetic.sh
chmod +x arithmetic.sh
./arithmetic.sh
```

السكريبت بيسأل المستخدم عن رقمين (`first number` و `second number`)، وبعدين بيحسب:
- **Sum** = الجمع
- **Difference** = الفرق
- **Multiplication** = حاصل الضرب
- **Division** = القسمة (integer division لأن Bash مش بيتعامل مع الكسور العشرية بشكل مباشر)
- **Modulus** = باقي القسمة

---

## نتيجة الاختبار (Test Run)

المدخلات: `10` و `20`

```
Entre first number: 10
Entre second number: 20
Sum = 30
Differece = -10
Multiplication = 200
Division = 0
Modulus = 10
```

![Arithmetic script output](arithmetic_output.png)

### تحقق من صحة النتائج
| العملية | الحساب | الناتج المتوقع | الناتج الفعلي | الحالة |
|---|---|---|---|---|
| Sum | 10 + 20 | 30 | 30 | ✅ |
| Difference | 10 - 20 | -10 | -10 | ✅ |
| Multiplication | 10 × 20 | 200 | 200 | ✅ |
| Division | 10 / 20 | 0 (integer division) | 0 | ✅ |
| Modulus | 10 % 20 | 10 | 10 | ✅ |

كل النتائج صحيحة حسابيًا. ✅

---

## ملاحظات وتحسينات مقترحة

1. **Typos في رسايل الإخراج (مش بتأثر على صحة النتيجة، بس تستحق التصليح):**
   - `Entre first number` → المفروض `Enter first number`
   - `Entre second number` → المفروض `Enter second number`
   - `Differece` → المفروض `Difference`

2. **Division = 0 غريبة الشكل بس صح:** لأن `10/20` في Bash بيتم حسابه كـ integer division (مفيش كسور عشرية)، فالناتج بيتقرب لأصغر عدد صحيح وهو 0. لو محتاجة نتيجة عشرية، ينفع تستخدم `bc` بدل الحساب المباشر، مثلاً:
   ```bash
   division=$(echo "scale=2; $num1 / $num2" | bc)
   ```

3. **ملاحظة غير متعلقة بالتاسك:** في أول السكريبت شوت ظهرت رسالة error خاصة بملف `.bash_profile`:
   ```
   -bash: /home/rahma11/.bash_profile: line 1: unexpected EOF while looking for matching ``'
   -bash: /home/rahma11/.bash_profile: line 2: syntax error: unexpected end of file
   ```
   ده مش له علاقة بسكريبت `arithmetic.sh` نفسه، لكنه معناه إن فيه syntax error (على الأغلب backtick `` ` `` مفتوح من غير ما يتقفل) جوه ملف `~/.bash_profile`. يفضل تفتحه وتتأكد إنه مظبوط عشان الرسالة متطلعش في كل مرة بتفتح فيها الترمينال.

---

## الخلاصة

السكريبت بيحقق كل متطلبات التاسك بنجاح والنتائج الحسابية صح 100%. الحاجة الوحيدة المطلوبة هي تصليح الـ typos في رسايل الطباعة، والاختياري تحسين الـ Division لو عايزة نتيجة عشرية بدل integer.
